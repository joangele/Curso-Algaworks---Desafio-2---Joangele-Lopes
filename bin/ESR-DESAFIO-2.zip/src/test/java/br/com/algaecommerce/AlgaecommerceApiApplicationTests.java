package br.com.algaecommerce;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlgaecommerceApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
